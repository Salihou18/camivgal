(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_jsx_61af54._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_jsx_61af54._.js",
  "chunks": [
    "static/chunks/node_modules_088a9c._.js",
    "static/chunks/[root of the server]__7040df._.js",
    "static/chunks/[root of the server]__b6e183._.css"
  ],
  "source": "dynamic"
});
