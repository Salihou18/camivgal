(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_jsx_2dc2ad._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_jsx_2dc2ad._.js",
  "chunks": [
    "static/chunks/app_page_jsx_4f1c05._.js"
  ],
  "source": "dynamic"
});
