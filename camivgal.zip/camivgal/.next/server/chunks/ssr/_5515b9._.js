module.exports = {

"[project]/public/img/Footer.webp [app-rsc] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/Footer.6e1d95b2.webp");}}),
"[project]/public/img/Footer.webp.mjs { IMAGE => \"[project]/public/img/Footer.webp [app-rsc] (static)\" } [app-rsc] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$Footer$2e$webp__$5b$app$2d$rsc$5d$__$28$static$29$__ = __turbopack_import__("[project]/public/img/Footer.webp [app-rsc] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$Footer$2e$webp__$5b$app$2d$rsc$5d$__$28$static$29$__["default"],
    width: 1065,
    height: 334,
    blurDataURL: "data:image/webp;base64,UklGRscAAABXRUJQVlA4TLsAAAAvB4AAAM1VICICHgiwCQAAAIB3RhcIHAQCAAAAAIAAAAAAAAAAAAAAAAAAAAAAAAAAR4hzShwAAMADATYBAAAAOP+AAjggBAQAAgAAAAAAAAAAAAAAAAAAAAAAAABAEQg6crEaAPdAgE0AAAAAzl+4cAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAgwMnCn2iZCJXvqVNqdjQGr7KvkmO93dPLHaNYT63Yaw2R/ZEQcZnp30U/gyKs9IjAA==",
    blurWidth: 8,
    blurHeight: 3
};
}}),
"[project]/public/img/Girrafe.webp [app-rsc] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/Girrafe.0513c16c.webp");}}),
"[project]/public/img/Girrafe.webp.mjs { IMAGE => \"[project]/public/img/Girrafe.webp [app-rsc] (static)\" } [app-rsc] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$Girrafe$2e$webp__$5b$app$2d$rsc$5d$__$28$static$29$__ = __turbopack_import__("[project]/public/img/Girrafe.webp [app-rsc] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$Girrafe$2e$webp__$5b$app$2d$rsc$5d$__$28$static$29$__["default"],
    width: 1024,
    height: 400,
    blurDataURL: "data:image/webp;base64,UklGRsAAAABXRUJQVlA4TLQAAAAvB4AAAM1VICICHggwDQAAAIArOeIEAAQAAAAAAAAAAAAAAAAAAAAgAAAAAAAAAAAEAOCe7QAAAB4ISA0AAADA+Q8mAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADCAzL+/eCDANAAAAADnf5wOAIADAAAAAAAAAAAAAAAAAAAAAAAgAAAAAAAAgANEH6ktsux7ObWXR1m85kkcmb4yt85g3Zdq+RAVUoTxwo2cd5QfvRA=",
    blurWidth: 8,
    blurHeight: 3
};
}}),
"[project]/public/img/Monument_de_la_Reunification.webp [app-rsc] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/Monument_de_la_Reunification.aa158af6.webp");}}),
"[project]/public/img/Monument_de_la_Reunification.webp.mjs { IMAGE => \"[project]/public/img/Monument_de_la_Reunification.webp [app-rsc] (static)\" } [app-rsc] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$Monument_de_la_Reunification$2e$webp__$5b$app$2d$rsc$5d$__$28$static$29$__ = __turbopack_import__("[project]/public/img/Monument_de_la_Reunification.webp [app-rsc] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$Monument_de_la_Reunification$2e$webp__$5b$app$2d$rsc$5d$__$28$static$29$__["default"],
    width: 800,
    height: 1067,
    blurDataURL: "data:image/webp;base64,UklGRgEBAABXRUJQVlA4TPUAAAAvBcABAM1VICICHgiACQMAAIDUekq/izcAAAAAAAAAAAAAABAAAAAAAAAAAICAAwc6QODujNP95QQAAAAPBMAGAQAA4Pxv0+bty/4klIADAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAETpGw8EIIUBAADg/Nf6ZwYYAAAAAAAMAAAAAAAAAAAAAAAAAAAAAAAAQBBgkfrKm9zaWmS4T4D5LFW5mZ/dwDN+v3UANZ3z8g8E+ACIYBqSO7MyIFzRskfTciXE7rfj2jWdq7xbJKu8lnyG9XJf1mv6mt7HoPRuKAHpFYlb2NuZBun5EMic58TLH2t3AgA=",
    blurWidth: 6,
    blurHeight: 8
};
}}),
"[project]/public/img/monument_de_la_renaissance_africaine.webp [app-rsc] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/monument_de_la_renaissance_africaine.e4dccb1d.webp");}}),
"[project]/public/img/monument_de_la_renaissance_africaine.webp.mjs { IMAGE => \"[project]/public/img/monument_de_la_renaissance_africaine.webp [app-rsc] (static)\" } [app-rsc] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$monument_de_la_renaissance_africaine$2e$webp__$5b$app$2d$rsc$5d$__$28$static$29$__ = __turbopack_import__("[project]/public/img/monument_de_la_renaissance_africaine.webp [app-rsc] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$monument_de_la_renaissance_africaine$2e$webp__$5b$app$2d$rsc$5d$__$28$static$29$__["default"],
    width: 1600,
    height: 1200,
    blurDataURL: "data:image/webp;base64,UklGRv0AAABXRUJQVlA4TPEAAAAvB0ABAM1VICICHgiADQIAAIDYm4eLBw6gAACAAAAcAAAAAAAAAAAAAADAIQABSABwmhd4AEeTezkAAAAPBCCFAQAA4Py76u+r9cEMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgAEAsKC1lQcCcAIBAABw/pJ8AAAAADwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM/PR9K1bf1WpLvvxgW4IxCFjGLj2tK78trBAf4nrGeL8vNXn3m1CIG46lyuj4tMb9JETxl0IHEcaytyZttt5Vm+P3vrr/YSucaNW7PgDp5GJX2pPiaQ7XN+FDaHRmQEAA==",
    blurWidth: 8,
    blurHeight: 6
};
}}),
"[project]/public/img/CircuitCam.webp [app-rsc] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/CircuitCam.82806535.webp");}}),
"[project]/public/img/CircuitCam.webp.mjs { IMAGE => \"[project]/public/img/CircuitCam.webp [app-rsc] (static)\" } [app-rsc] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$CircuitCam$2e$webp__$5b$app$2d$rsc$5d$__$28$static$29$__ = __turbopack_import__("[project]/public/img/CircuitCam.webp [app-rsc] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$CircuitCam$2e$webp__$5b$app$2d$rsc$5d$__$28$static$29$__["default"],
    width: 800,
    height: 450,
    blurDataURL: "data:image/webp;base64,UklGRu8AAABXRUJQVlA4TOMAAAAvBwABAM1VICICHgiACQMAAIDz048gFAAAAAAAAAAAAAAAAAAAAAAAXOcEAILAAEAACAUv/QszeAAAADwQgBMIAACA87cSDUESDfDeAAAAAAAAAAAAAAAAAAAAAIAAIAgAAAAAgACCLDkPBMAGAQAA4PwrnwWBgwDAAUA4AAAAAAAAAAAAAAAAAAAAAAAAgEGuH8ehM0jfeC/yWjsfIMODPhVlpZ+x4DVBCMoFqXqodeMO7+m729tgbvnGL+5Kv5yp5txS1PABidZpsxyH7t5Mty27sAgoQzqmogXleX+uuT0PAAA=",
    blurWidth: 8,
    blurHeight: 5
};
}}),
"[project]/public/img/CircuitSen.webp [app-rsc] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/CircuitSen.5ab6daea.webp");}}),
"[project]/public/img/CircuitSen.webp.mjs { IMAGE => \"[project]/public/img/CircuitSen.webp [app-rsc] (static)\" } [app-rsc] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$CircuitSen$2e$webp__$5b$app$2d$rsc$5d$__$28$static$29$__ = __turbopack_import__("[project]/public/img/CircuitSen.webp [app-rsc] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$CircuitSen$2e$webp__$5b$app$2d$rsc$5d$__$28$static$29$__["default"],
    width: 1280,
    height: 780,
    blurDataURL: "data:image/webp;base64,UklGRtsAAABXRUJQVlA4TM8AAAAvBwABAM1VICICHghACgMAAIDftwIeIBgDADAAAAAAAAAAAAAAAAAAAAAAQAAAgEAAD8NQ9LaJwgEAAHggICkQAAAA5z+zGwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgBz9lwcCbAIAAABw/rve5AQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAL1vkTkvJDaAZyIYw1gPTr0CqEAlSTvGa6trNTqq079v8aHnjiwd+RZLOrYRTNd/2YY2h/Y9p64veaqf2iUA",
    blurWidth: 8,
    blurHeight: 5
};
}}),
"[project]/public/img/CircuitCiv.webp [app-rsc] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/CircuitCiv.61558e27.webp");}}),
"[project]/public/img/CircuitCiv.webp.mjs { IMAGE => \"[project]/public/img/CircuitCiv.webp [app-rsc] (static)\" } [app-rsc] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$CircuitCiv$2e$webp__$5b$app$2d$rsc$5d$__$28$static$29$__ = __turbopack_import__("[project]/public/img/CircuitCiv.webp [app-rsc] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$CircuitCiv$2e$webp__$5b$app$2d$rsc$5d$__$28$static$29$__["default"],
    width: 1280,
    height: 780,
    blurDataURL: "data:image/webp;base64,UklGRucAAABXRUJQVlA4TNsAAAAvBwABAM1VICICHgiACQMAAIAIBMiBOUBIPwQ4AAAAAAAAAAAAAAAAAAcAwAE4WJyr4IcDCQAfmQEAAOCBAJxAAAAAnP9S9w0yA/IAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAunYeCAANAwAAwPlXqwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGAMTPzbWhSL3HsZPRKKQBpoAzYcwiL7zG+udB1vYMXFfKvcx/OUuGibGiTwZMG1blV/G/OPo/Y3ZXoQgNY43eWgZnKpRrn5Hw/6eQwA",
    blurWidth: 8,
    blurHeight: 5
};
}}),
"[project]/public/img/TourismeCam.webp [app-rsc] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/TourismeCam.fd1a05de.webp");}}),
"[project]/public/img/TourismeCam.webp.mjs { IMAGE => \"[project]/public/img/TourismeCam.webp [app-rsc] (static)\" } [app-rsc] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$TourismeCam$2e$webp__$5b$app$2d$rsc$5d$__$28$static$29$__ = __turbopack_import__("[project]/public/img/TourismeCam.webp [app-rsc] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$TourismeCam$2e$webp__$5b$app$2d$rsc$5d$__$28$static$29$__["default"],
    width: 768,
    height: 934,
    blurDataURL: "data:image/webp;base64,UklGRgQBAABXRUJQVlA4TPgAAAAvBsABAM1VICICHgiADQIAAAClBwTiBACgJACBAAAAAAAAAAAAAAAAAAAAIPTwAUgVADoUdMrL/jYAAAAPBCCFAQAA4Pzvbt+vdckCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGIDlPRCAIgYAAIDzv9t6BgMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgqdJ+Xx9pSrhgY2v7/Uv1vTFGArAa9oRlw9L+1Yh1KvWcy4gHINU0Y7Vt4cp6gViHANQeHRDpGj/BN/4Es02u2XyDxzX286AQSJkrGy103LkDSKSvKyVqZ5HVdu8eLfvf3F+uBg==",
    blurWidth: 7,
    blurHeight: 8
};
}}),
"[project]/public/img/TourismeSen.webp [app-rsc] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/TourismeSen.8c2721f9.webp");}}),
"[project]/public/img/TourismeSen.webp.mjs { IMAGE => \"[project]/public/img/TourismeSen.webp [app-rsc] (static)\" } [app-rsc] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$TourismeSen$2e$webp__$5b$app$2d$rsc$5d$__$28$static$29$__ = __turbopack_import__("[project]/public/img/TourismeSen.webp [app-rsc] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$TourismeSen$2e$webp__$5b$app$2d$rsc$5d$__$28$static$29$__["default"],
    width: 768,
    height: 439,
    blurDataURL: "data:image/webp;base64,UklGRugAAABXRUJQVlA4TNwAAAAvBwABAM1VICICHgiACQMAAIBuJgGAAAABAgAAAAAAAAAAAAAAAAAIAAAAHAgAEhyAu5A6H1XsAwAA8EAATiAAAADOv1X1GGACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgIKAAC77na5cHAnACAQAAcP47Ux4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABCCAJpeW9sWGVbHwwBGQC5+EAPb+JQRy7xkdZN3au9eGt0VltNzOJRxeQRXOTCZJtM76gSNr2n7XqKvBmr6zKrp/5+4Kcuix48KX5AD",
    blurWidth: 8,
    blurHeight: 5
};
}}),
"[project]/public/img/TourismeCiv.webp [app-rsc] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/TourismeCiv.6de62686.webp");}}),
"[project]/public/img/TourismeCiv.webp.mjs { IMAGE => \"[project]/public/img/TourismeCiv.webp [app-rsc] (static)\" } [app-rsc] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$TourismeCiv$2e$webp__$5b$app$2d$rsc$5d$__$28$static$29$__ = __turbopack_import__("[project]/public/img/TourismeCiv.webp [app-rsc] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$TourismeCiv$2e$webp__$5b$app$2d$rsc$5d$__$28$static$29$__["default"],
    width: 768,
    height: 512,
    blurDataURL: "data:image/webp;base64,UklGRuwAAABXRUJQVlA4TOAAAAAvBwABAM1VICICHgiACQMAAIDt9q4OHBAAAQAAAAAAAAAAAAAAAAAQAAAAgACBIJQA+A7gQEGhAgAA8EAATBgAAADOf9uyv/I4p51UBQAAAAAAAAAAAAAAAAAAAAAAAAAAACAAAAAAuHU8EIATCAAAgPNfLZIAAAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQKt/VBQBBUC3SLuSBD5+EmwRDZAiYiHcvf3Vk/78FlbJj8TUQpgjf1DLXbIZQ4/1dNkt/7NeQiqq8K8dd57ndEoCYiD5Cu61UD5m029zJ7chAg==",
    blurWidth: 8,
    blurHeight: 5
};
}}),
"[project]/components/ServicesSection.jsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
;
;
{}const ServicesSection = ({ title, services, className = 'py-10 bg-white' })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: `nos-services ${className}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-2xl font-bold text-center mb-4",
                children: title
            }, void 0, false, {
                fileName: "[project]/components/ServicesSection.jsx",
                lineNumber: 7,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-wrap justify-center gap-6",
                children: services.map((service, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "service-card p-4 shadow-md rounded-md w-64 text-center text-white flex items-end justify-center",
                        style: {
                            backgroundImage: `url(${service.image.src})`,
                            backgroundSize: 'cover',
                            backgroundPosition: 'center',
                            height: '300px',
                            width: '350px'
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-black bg-opacity-50 w-full p-4 rounded-b-md",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-xl font-semibold",
                                children: service.title
                            }, void 0, false, {
                                fileName: "[project]/components/ServicesSection.jsx",
                                lineNumber: 20,
                                columnNumber: 29
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/ServicesSection.jsx",
                            lineNumber: 19,
                            columnNumber: 25
                        }, this)
                    }, index, false, {
                        fileName: "[project]/components/ServicesSection.jsx",
                        lineNumber: 11,
                        columnNumber: 21
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/ServicesSection.jsx",
                lineNumber: 9,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/ServicesSection.jsx",
        lineNumber: 6,
        columnNumber: 9
    }, this);
};
const __TURBOPACK__default__export__ = ServicesSection;
}}),
"[project]/app/page.jsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>Home)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/image.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$Footer$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$img$2f$Footer$2e$webp__$5b$app$2d$rsc$5d$__$28$static$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/public/img/Footer.webp.mjs { IMAGE => "[project]/public/img/Footer.webp [app-rsc] (static)" } [app-rsc] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$Girrafe$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$img$2f$Girrafe$2e$webp__$5b$app$2d$rsc$5d$__$28$static$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/public/img/Girrafe.webp.mjs { IMAGE => "[project]/public/img/Girrafe.webp [app-rsc] (static)" } [app-rsc] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$Monument_de_la_Reunification$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$img$2f$Monument_de_la_Reunification$2e$webp__$5b$app$2d$rsc$5d$__$28$static$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/public/img/Monument_de_la_Reunification.webp.mjs { IMAGE => "[project]/public/img/Monument_de_la_Reunification.webp [app-rsc] (static)" } [app-rsc] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$monument_de_la_renaissance_africaine$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$img$2f$monument_de_la_renaissance_africaine$2e$webp__$5b$app$2d$rsc$5d$__$28$static$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/public/img/monument_de_la_renaissance_africaine.webp.mjs { IMAGE => "[project]/public/img/monument_de_la_renaissance_africaine.webp [app-rsc] (static)" } [app-rsc] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$CircuitCam$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$img$2f$CircuitCam$2e$webp__$5b$app$2d$rsc$5d$__$28$static$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/public/img/CircuitCam.webp.mjs { IMAGE => "[project]/public/img/CircuitCam.webp [app-rsc] (static)" } [app-rsc] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$CircuitSen$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$img$2f$CircuitSen$2e$webp__$5b$app$2d$rsc$5d$__$28$static$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/public/img/CircuitSen.webp.mjs { IMAGE => "[project]/public/img/CircuitSen.webp [app-rsc] (static)" } [app-rsc] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$CircuitCiv$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$img$2f$CircuitCiv$2e$webp__$5b$app$2d$rsc$5d$__$28$static$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/public/img/CircuitCiv.webp.mjs { IMAGE => "[project]/public/img/CircuitCiv.webp [app-rsc] (static)" } [app-rsc] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$TourismeCam$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$img$2f$TourismeCam$2e$webp__$5b$app$2d$rsc$5d$__$28$static$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/public/img/TourismeCam.webp.mjs { IMAGE => "[project]/public/img/TourismeCam.webp [app-rsc] (static)" } [app-rsc] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$TourismeSen$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$img$2f$TourismeSen$2e$webp__$5b$app$2d$rsc$5d$__$28$static$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/public/img/TourismeSen.webp.mjs { IMAGE => "[project]/public/img/TourismeSen.webp [app-rsc] (static)" } [app-rsc] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$TourismeCiv$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$img$2f$TourismeCiv$2e$webp__$5b$app$2d$rsc$5d$__$28$static$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/public/img/TourismeCiv.webp.mjs { IMAGE => "[project]/public/img/TourismeCiv.webp [app-rsc] (static)" } [app-rsc] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ServicesSection$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/components/ServicesSection.jsx [app-rsc] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
function Home() {
    {}
    const services = [
        {
            title: 'Culture du Cameroun',
            image: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$Monument_de_la_Reunification$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$img$2f$Monument_de_la_Reunification$2e$webp__$5b$app$2d$rsc$5d$__$28$static$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
        },
        {
            title: 'Culture de la Côte d\'Ivoire',
            image: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$Girrafe$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$img$2f$Girrafe$2e$webp__$5b$app$2d$rsc$5d$__$28$static$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
        },
        {
            title: 'Culture du Sénégal',
            image: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$monument_de_la_renaissance_africaine$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$img$2f$monument_de_la_renaissance_africaine$2e$webp__$5b$app$2d$rsc$5d$__$28$static$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
        }
    ];
    const circuits = [
        {
            title: 'Circuits du Cameroun',
            image: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$CircuitCam$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$img$2f$CircuitCam$2e$webp__$5b$app$2d$rsc$5d$__$28$static$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
        },
        {
            title: 'Circuits de la Côte d\'Ivoire',
            image: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$CircuitCiv$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$img$2f$CircuitCiv$2e$webp__$5b$app$2d$rsc$5d$__$28$static$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
        },
        {
            title: 'Circuits du Sénégal',
            image: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$CircuitSen$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$img$2f$CircuitSen$2e$webp__$5b$app$2d$rsc$5d$__$28$static$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
        }
    ];
    const tourisme = [
        {
            title: 'Tourisme du Cameroun',
            image: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$TourismeCam$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$img$2f$TourismeCam$2e$webp__$5b$app$2d$rsc$5d$__$28$static$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
        },
        {
            title: 'Tourisme de la Côte d\'Ivoire',
            image: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$TourismeCiv$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$img$2f$TourismeCiv$2e$webp__$5b$app$2d$rsc$5d$__$28$static$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
        },
        {
            title: 'Tourisme du Sénégal',
            image: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$TourismeSen$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$img$2f$TourismeSen$2e$webp__$5b$app$2d$rsc$5d$__$28$static$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "space-y-8",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "footer bg-cover bg-center flex items-center justify-center font-serif",
                style: {
                    backgroundImage: `url(${__TURBOPACK__imported__module__$5b$project$5d2f$public$2f$img$2f$Footer$2e$webp$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$img$2f$Footer$2e$webp__$5b$app$2d$rsc$5d$__$28$static$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"].src})`,
                    height: '400px'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-3xl text-white text-center leading-relaxed font-bold animate-scan",
                    children: "Bienvenue chez Camivgal, pour découvrir le Cameroun, la Côte d'Ivoire et le Sénégal !"
                }, void 0, false, {
                    fileName: "[project]/app/page.jsx",
                    lineNumber: 44,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/page.jsx",
                lineNumber: 38,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ServicesSection$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                title: "Nos Services",
                services: services
            }, void 0, false, {
                fileName: "[project]/app/page.jsx",
                lineNumber: 50,
                columnNumber: 8
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ServicesSection$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                title: "Nos Circuits",
                services: circuits
            }, void 0, false, {
                fileName: "[project]/app/page.jsx",
                lineNumber: 53,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ServicesSection$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                title: "Tourisme",
                services: tourisme
            }, void 0, false, {
                fileName: "[project]/app/page.jsx",
                lineNumber: 56,
                columnNumber: 15
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/page.jsx",
        lineNumber: 37,
        columnNumber: 9
    }, this);
}
}}),
"[project]/app/page.jsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_namespace__(__turbopack_import__("[project]/app/page.jsx [app-rsc] (ecmascript)"));
}}),
"[project]/.next-internal/server/app/page/actions.js [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
}}),

};

//# sourceMappingURL=_5515b9._.js.map