export default function Contact() {
    return <div>Page de contact</div>;
   }
   