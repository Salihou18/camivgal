export default function Document(){
const docList = [
    
]

return(
    <div className="max-w-6xl justify-center-mx-auto">
        <div>
            <h1>Titre: NE TIREZ PAS SUR L&apos;OISEAU MOQUEUR </h1>
            <p>Auteur: Harper Lee </p>
            <p>Annee: 1960 </p>
            <p>Genre: Roman </p>
            <p>
                {""}
                Description: Un roman qui tient à la fois de la fiction mêlée d&apos;éléments biographiques 
                et du roman d&apos;apprentissage, mais qui contient également les éléments d&apos;un thriller qui le rapprochent du roman policier. 
                Prix Pulitzer, le chef-d&apos;oeuvre traite de l&apos;héroïsme 
                d&apos;une homme face à une haine raciale aveugle et violente dans le sud des États-Unis.
            </p>
        </div>
    </div>
)
}