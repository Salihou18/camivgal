# CAMIVGAL qu'est ce que c'est?

## Mise en contexte

### L'Afrique est un continent connu mondialement pour ses paysages chaleureux, sa faune et sa flore variée et  l'hospitalité  de ses ressortissants. Dans le but de promouvoir les sites touristiques et les paysages africains, Camivgal est un jeu de mot entre Cameroun, Cote D'Ivoire Senegal.

## Liens utiles pour notre projet

### Cameroun (Par Salihou Kingue) https://generationvoyage.fr/endroits-visiter-cameroun/

### CIV (Par Prunelle Eckshar) https://discover-ivorycoast.com/les-attractions/

### Senegal (Par Bara DJigal) https://generationvoyage.fr/endroits-visiter-senegal/

